import streamlit as st
import sqlite3
import cv2
import numpy as np
import bcrypt
import face_recognition
import json

# Configuration de la base de données
DATABASE_PATH = "reconnaissance.db"

# Fonctions de gestion de la base de données
def get_db_connection():
    """Établit une connexion à la base de données."""
    return sqlite3.connect(DATABASE_PATH)

def drop_table():
    """Supprime la table reconnaissance si elle existe."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DROP TABLE IF EXISTS reconnaissance;")
        conn.commit()

def init_database():
    """Initialise la base de données si elle n'existe pas."""
    drop_table()  # Supprimez la table si elle existe
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS reconnaissance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                email TEXT UNIQUE,
                password TEXT,
                face_encoding TEXT,
                gmail_id TEXT,
                facebook_id TEXT
            )
        ''')

def create_user(username, email, password, face_encoding, gmail_id=None, facebook_id=None):
    """Crée un nouvel utilisateur dans la base de données."""
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    face_encoding_json = json.dumps(face_encoding.tolist()) if face_encoding is not None else None
    try:
        with get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO reconnaissance (username, email, password, face_encoding, gmail_id, facebook_id) VALUES (?, ?, ?, ?, ?, ?)",
                           (username, email, hashed_password, face_encoding_json, gmail_id, facebook_id))
        st.success("Utilisateur créé avec succès!")
    except sqlite3.IntegrityError:
        st.error("Nom d'utilisateur ou email déjà utilisé.")

def fetch_user(username=None, email=None, gmail_id=None, facebook_id=None):
    """Récupère les informations d'un utilisateur depuis la base de données."""
    with get_db_connection() as conn:
        cursor = conn.cursor()
        if username:
            cursor.execute("SELECT * FROM reconnaissance WHERE username = ?", (username,))
        elif email:
            cursor.execute("SELECT * FROM reconnaissance WHERE email = ?", (email,))
        elif gmail_id:
            cursor.execute("SELECT * FROM reconnaissance WHERE gmail_id = ?", (gmail_id,))
        elif facebook_id:
            cursor.execute("SELECT * FROM reconnaissance WHERE facebook_id = ?", (facebook_id,))
        return cursor.fetchone()

# Fonctions de gestion des visages
def capture_face():
    """Capture une image du visage depuis la webcam."""
    cap = cv2.VideoCapture(0)
    ret, frame = cap.read()
    cap.release()
    return frame if ret else None

def encode_face(image):
    """Encode le visage dans une image."""
    face_locations = face_recognition.face_locations(image)
    return face_recognition.face_encodings(image, face_locations)[0] if face_locations else None

def compare_faces(encoding1, encoding2):
    """Compare deux encodages de visage."""
    return np.linalg.norm(encoding1 - encoding2) < 0.6

# Interface Streamlit
def main():
    st.title("Reconnaissance Faciale")
    menu = st.sidebar.radio("Menu", ["Inscription", "Connexion"])

    if menu == "Inscription":
        username = st.text_input("Nom d'utilisateur")
        email = st.text_input("Email")
        password = st.text_input("Mot de passe", type="password")

        if st.button("Prendre une photo"):
            image = capture_face()
            if image is not None:
                st.image(image, channels="BGR")
                encoding = encode_face(image)
                if encoding is not None:
                    create_user(username, email, password, encoding)
                else:
                    st.error("Aucun visage détecté.")
            else:
                st.error("Impossible de capturer l'image.")

    elif menu == "Connexion":
        username = st.text_input("Nom d'utilisateur")
        password = st.text_input("Mot de passe", type="password")

        if st.button("Se connecter"):
            user = fetch_user(username=username)
            if user:
                if bcrypt.checkpw(password.encode('utf-8'), user[3].encode('utf-8')):
                    st.success(f"Bienvenue, {user[1]}!")
                else:
                    st.error("Mot de passe incorrect.")
            else:
                st.error("Nom d'utilisateur incorrect.")

        # Authentification par réseaux sociaux
        st.subheader("Ou connectez-vous avec")
        if st.button("Se connecter avec Gmail"):
            # Simuler la connexion avec Gmail
            gmail_id = "gmail_user_123"  # Remplacez par l'ID réel de Gmail
            user = fetch_user(gmail_id=gmail_id)
            if user:
                st.success(f"Bienvenue, {user[1]} (via Gmail)!")
            else:
                st.warning("Utilisateur Gmail non trouvé. Veuillez vous inscrire.")
        if st.button("Se connecter avec Facebook"):
            # Simuler la connexion avec Facebook
            facebook_id = "facebook_user_456"  # Remplacez par l'ID réel de Facebook
            user = fetch_user(facebook_id=facebook_id)
            if user:
                st.success(f"Bienvenue, {user[1]} (via Facebook)!")
            else:
                st.warning("Utilisateur Facebook non trouvé. Veuillez vous inscrire.")

        # Reconnaissance faciale pour la connexion
        st.subheader("Connexion par reconnaissance faciale")
        if st.button("Se connecter avec la caméra"):
            image = capture_face()
            if image is not None:
                encoding = encode_face(image)
                if encoding is not None:
                    with get_db_connection() as conn:
                        cursor = conn.cursor()
                        cursor.execute("SELECT * FROM reconnaissance WHERE face_encoding IS NOT NULL")
                        users = cursor.fetchall()

                    for user in users:
                        stored_encoding = json.loads(user[4])
                        if compare_faces(encoding, np.array(stored_encoding)):
                            st.success(f"Bienvenue, {user[1]} (reconnaissance faciale)!")
                            break
                    else:
                        st.error("Visage non reconnu.")
                else:
                    st.error("Aucun visage détecté.")
            else:
                st.error("Impossible de capturer l'image.")

if __name__ == "__main__":
    init_database()
    main()